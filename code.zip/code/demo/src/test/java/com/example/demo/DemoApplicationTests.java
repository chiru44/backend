//package com.example.demo;
//
//import org.junit.Test;
//import org.junit.runner.RunWith;
//
//
//import com.example.demo.controller.StudentController;
//
//
//public class DemoApplicationTests {
//
//	@Test
//	public void contextLoads() {
//	}
//
//}
